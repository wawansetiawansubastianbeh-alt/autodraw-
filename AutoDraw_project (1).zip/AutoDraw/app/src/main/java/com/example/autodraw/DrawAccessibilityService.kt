package com.example.autodraw

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.hypot

class DrawAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: DrawAccessibilityService? = null
    }

    @Volatile
    private var cancelled = false

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun cancel() {
        cancelled = true
    }

    /** Menggambar semua goresan berurutan. Beberapa goresan digabung dalam satu gesture agar cepat. */
    fun draw(
        strokes: List<List<PointF>>,
        msPerPx: Float,
        onProgress: (Int, Int) -> Unit,
        onDone: (Boolean) -> Unit
    ) {
        cancelled = false
        val handler = Handler(Looper.getMainLooper())
        val maxStrokes = GestureDescription.getMaxStrokeCount().coerceAtLeast(1)
        var idx = 0

        fun next() {
            if (cancelled || idx >= strokes.size) {
                onDone(!cancelled)
                return
            }
            val builder = GestureDescription.Builder()
            var t = 0L
            var n = 0
            while (idx < strokes.size && n < maxStrokes && t < 20000L) {
                val pts = strokes[idx]
                idx++
                if (pts.size < 2) continue
                val path = Path()
                path.moveTo(pts[0].x, pts[0].y)
                var len = 0f
                for (i in 1 until pts.size) {
                    path.lineTo(pts[i].x, pts[i].y)
                    len += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
                }
                val dur = (len * msPerPx).toLong().coerceIn(30L, 20000L)
                builder.addStroke(GestureDescription.StrokeDescription(path, t, dur))
                t += dur + 30L
                n++
            }
            if (n == 0) {
                next()
                return
            }
            val ok = dispatchGesture(builder.build(), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    onProgress(idx, strokes.size)
                    next()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    onProgress(idx, strokes.size)
                    next()
                }
            }, handler)
            if (!ok) onDone(false)
        }
        next()
    }
}
