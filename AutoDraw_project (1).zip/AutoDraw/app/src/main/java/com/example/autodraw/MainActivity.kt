package com.example.autodraw

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Path
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 96, 56, 56)
        }
        root.addView(TextView(this).apply {
            text = "AutoDraw"
            textSize = 28f
            setTextColor(Color.BLACK)
        })
        info = TextView(this).apply {
            textSize = 14f
            setPadding(0, 24, 0, 24)
        }
        root.addView(info)

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
        }

        root.addView(button("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("2. Aktifkan layanan aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Tes layanan aksesibilitas") { testAcc() })
        root.addView(button("3. Matikan penghematan baterai (disarankan)") {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        root.addView(button("4. Mulai AutoDraw") { start() })

        root.addView(TextView(this).apply {
            textSize = 12f
            setPadding(0, 32, 0, 0)
            text = "Saat diminta berbagi layar, pilih \"Seluruh layar\" (bukan satu aplikasi).\n\n" +
                    "Jika tombol aksesibilitas abu-abu (APK dari luar Play Store): buka Info Aplikasi AutoDraw → " +
                    "menu ⋮ → \"Izinkan setelan terbatas\", lalu ulangi langkah 2."
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ov = Settings.canDrawOverlays(this)
        val acc = DrawAccessibilityService.instance != null
        val listed = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        val accText = when {
            acc -> "✓ aktif & tersambung"
            listed -> "⚠ dicentang tapi belum tersambung (matikan lalu hidupkan lagi)"
            else -> "✗ belum diaktifkan"
        }
        info.text = "Tampil di atas aplikasi lain: ${if (ov) "✓ aktif" else "✗ belum"}\n" +
                "Layanan aksesibilitas: $accText"
    }

    private fun testAcc() {
        val svc = DrawAccessibilityService.instance
        if (svc == null) {
            Toast.makeText(
                this,
                "Belum tersambung. Matikan lalu hidupkan lagi layanan AutoDraw di Pengaturan > Aksesibilitas.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val path = Path().apply { moveTo(5f, 5f); lineTo(6f, 6f) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        val sent = svc.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                Toast.makeText(this@MainActivity, "Tes berhasil ✓ sentuhan otomatis berfungsi", Toast.LENGTH_LONG).show()
            }
            override fun onCancelled(d: GestureDescription?) {
                Toast.makeText(this@MainActivity, "Sentuhan dibatalkan sistem", Toast.LENGTH_LONG).show()
            }
        }, null)
        if (!sent) Toast.makeText(this, "Sistem menolak sentuhan otomatis", Toast.LENGTH_LONG).show()
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan overlay dulu (langkah 1)", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .setAction(OverlayService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
