package com.example.autodraw

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "autodraw.START"
        const val ACTION_STOP_DRAW = "autodraw.STOP_DRAW"
        const val ACTION_QUIT = "autodraw.QUIT"
        private const val CHANNEL = "autodraw"

        private val DETAIL_NAMES = arrayOf("Rendah", "Sedang", "Tinggi")
        private val DETAIL_DIM = intArrayOf(120, 180, 260)
        private val DETAIL_THR = intArrayOf(220, 140, 90)
        private val SPEED_NAMES = arrayOf("Lambat", "Sedang", "Cepat")
        private val SPEED_MS = floatArrayOf(6f, 3f, 1.2f)
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var sw = 0
    private var sh = 0

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var selection: SelectionView? = null
    private var status: TextView? = null
    private var detailBtn: TextView? = null
    private var speedBtn: TextView? = null

    private var srcBitmap: Bitmap? = null
    private var trace: TraceResult? = null
    private var target: Rect? = null
    private var detail = 1
    private var speed = 1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val i = intent ?: return START_NOT_STICKY
        when (i.action) {
            ACTION_START -> {
                startAsForeground()
                if (projection == null) {
                    @Suppress("DEPRECATION")
                    val data: Intent? = i.getParcelableExtra("data")
                    val code = i.getIntExtra("code", 0)
                    if (data == null || !setupCapture(code, data)) {
                        toast("Gagal memulai tangkapan layar")
                        stopSelf()
                        return START_NOT_STICKY
                    }
                    buildPanel()
                }
            }
            ACTION_STOP_DRAW -> DrawAccessibilityService.instance?.cancel()
            ACTION_QUIT -> stopSelf()
        }
        return START_NOT_STICKY
    }

    // ---------- Foreground & capture ----------

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "AutoDraw", NotificationManager.IMPORTANCE_LOW))
        fun pi(action: String) = PendingIntent.getService(
            this, action.hashCode(),
            Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("AutoDraw aktif")
            .setContentText("Gunakan tombol di bawah untuk menghentikan")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(android.R.drawable.ic_media_pause, "Stop gambar", pi(ACTION_STOP_DRAW))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Tutup", pi(ACTION_QUIT))
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupCapture(code: Int, data: Intent): Boolean {
        return try {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            sw = dm.widthPixels
            sh = dm.heightPixels
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }, main)
            projection = p
            val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
            reader = r
            vd = p.createVirtualDisplay(
                "autodraw", sw, sh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun acquireFrame(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val pl = img.planes[0]
            val rowPad = pl.rowStride - pl.pixelStride * img.width
            val b = Bitmap.createBitmap(img.width + rowPad / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            b.copyPixelsFromBuffer(pl.buffer)
            return b
        } finally {
            img.close()
        }
    }

    // ---------- UI ----------

    private fun fullParams() = WindowManager.LayoutParams(
        sw, sh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 0; y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun roundBg(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private fun btn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(28, 18, 28, 18)
        background = roundBg(0xFF3C4043.toInt(), 20f)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 8 }
        setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(0xEE202124.toInt(), 28f)
            setPadding(16, 12, 16, 16)
        }
        val handle = TextView(this).apply {
            text = "≡  AutoDraw"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
        }
        val st = TextView(this).apply {
            text = "1) Ambil gambar referensi"
            setTextColor(0xFFB0BEC5.toInt())
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 4)
        }
        status = st

        box.addView(handle)
        box.addView(st)
        box.addView(btn("1 · Ambil gambar") { pickSource() })
        box.addView(btn("2 · Pilih kanvas") { pickTarget() })
        box.addView(btn("▶  Mulai gambar") { startDraw() })
        detailBtn = btn("Detail: ${DETAIL_NAMES[detail]}") { cycleDetail() }
        speedBtn = btn("Kecepatan: ${SPEED_NAMES[speed]}") { cycleSpeed() }
        box.addView(detailBtn)
        box.addView(speedBtn)
        box.addView(btn("✕  Tutup") { stopSelf() })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 300 }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }
        panel = box
        panelLp = lp
        wm.addView(box, lp)
    }

    private fun setStatus(s: String) { status?.text = s }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun setPanelTouchable(touchable: Boolean) {
        val p = panel ?: return
        val lp = panelLp ?: return
        lp.flags = if (touchable)
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        p.alpha = if (touchable) 1f else 0.35f
        wm.updateViewLayout(p, lp)
    }

    // ---------- Aksi ----------

    private fun pickRegion(title: String, cb: (Rect) -> Unit) {
        if (selection != null) return
        panel?.visibility = View.INVISIBLE
        lateinit var v: SelectionView
        v = SelectionView(this, title) { rect ->
            main.post {
                try { wm.removeView(v) } catch (_: Exception) {}
                selection = null
                if (rect != null) cb(rect) else panel?.visibility = View.VISIBLE
            }
        }
        selection = v
        wm.addView(v, fullParams())
    }

    private fun pickSource() {
        pickRegion("Pilih gambar yang akan ditiru") { rect ->
            // beri waktu overlay hilang agar tidak ikut tertangkap
            main.postDelayed({ captureSource(rect) }, 350)
        }
    }

    private fun captureSource(rect: Rect) {
        Thread {
            var frame: Bitmap? = null
            for (k in 0 until 12) {
                frame = acquireFrame()
                if (frame != null) break
                Thread.sleep(120)
            }
            val f = frame
            if (f == null) {
                main.post { panel?.visibility = View.VISIBLE; toast("Tidak ada frame layar. Coba lagi.") }
                return@Thread
            }
            val l = rect.left.coerceIn(0, f.width - 2)
            val t = rect.top.coerceIn(0, f.height - 2)
            val w = rect.width().coerceAtMost(f.width - l)
            val h = rect.height().coerceAtMost(f.height - t)
            val crop = Bitmap.createBitmap(f, l, t, w, h)
            main.post {
                srcBitmap = crop
                panel?.visibility = View.VISIBLE
                runTrace()
            }
        }.start()
    }

    private fun runTrace() {
        val src = srcBitmap ?: return
        setStatus("Memproses gambar…")
        val d = detail
        Thread {
            val r = Tracer.trace(src, DETAIL_DIM[d], DETAIL_THR[d])
            main.post {
                trace = r
                setStatus("Gambar siap: ${r.strokes.size} goresan\n2) Pilih kanvas")
            }
        }.start()
    }

    private fun pickTarget() {
        pickRegion("Pilih area kanvas tempat menggambar") { rect ->
            target = rect
            panel?.visibility = View.VISIBLE
            setStatus("Kanvas dipilih ✓\n3) Tekan Mulai gambar")
        }
    }

    private fun cycleDetail() {
        detail = (detail + 1) % DETAIL_NAMES.size
        detailBtn?.text = "Detail: ${DETAIL_NAMES[detail]}"
        if (srcBitmap != null) runTrace()
    }

    private fun cycleSpeed() {
        speed = (speed + 1) % SPEED_NAMES.size
        speedBtn?.text = "Kecepatan: ${SPEED_NAMES[speed]}"
    }

    private fun accEnabledInSettings(): Boolean {
        val v = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return v?.contains(packageName) == true
    }

    private fun startDraw() {
        val r = trace
        val t = target
        val svc = DrawAccessibilityService.instance
        when {
            r == null -> { toast("Ambil gambar dulu (tombol 1)"); return }
            t == null -> { toast("Pilih area kanvas dulu (tombol 2)"); return }
            svc == null -> {
                if (accEnabledInSettings()) {
                    toast("Layanan tercatat aktif tapi belum tersambung. Matikan lalu hidupkan lagi layanan AutoDraw, lalu coba lagi.")
                } else {
                    toast("Aktifkan layanan aksesibilitas AutoDraw dulu.")
                }
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
                return
            }
        }
        val s = minOf(t!!.width().toFloat() / r!!.w, t.height().toFloat() / r.h)
        val ox = t.left + (t.width() - r.w * s) / 2f
        val oy = t.top + (t.height() - r.h * s) / 2f
        val mapped = r.strokes.map { st -> st.map { PointF(ox + it.x * s, oy + it.y * s) } }

        setPanelTouchable(false)
        setStatus("Mulai dalam sekejap…\n(Stop lewat notifikasi)")
        main.postDelayed({
            svc!!.draw(
                mapped, SPEED_MS[speed],
                { d, n -> main.post { setStatus("Menggambar $d/$n") } },
                { ok ->
                    main.post {
                        setPanelTouchable(true)
                        setStatus(if (ok) "Selesai ✓" else "Dihentikan")
                    }
                }
            )
        }, 500)
    }

    override fun onDestroy() {
        DrawAccessibilityService.instance?.cancel()
        try { selection?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        vd?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
